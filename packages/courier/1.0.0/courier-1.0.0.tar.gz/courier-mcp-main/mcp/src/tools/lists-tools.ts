import z from "zod";
import { CourierMcpTools } from "./courier-mcp-tools.js";

export class ListsTools extends CourierMcpTools {

  static readonly tools: string[] = [
    'list_lists',
    'get_list',
    'get_list_subscribers',
    'create_list',
    'subscribe_user_to_list',
    'unsubscribe_user_from_list',
  ];

  public register() {

    // List all lists
    this.registerToolIfNeeded(
      ListsTools.tools[0],
      "Returns all of the lists, with the ability to filter based on a pattern.",
      {
        pattern: z.string().optional(),
        cursor: z.string().optional(),
        limit: z.number().optional(),
      },
      async ({ pattern, cursor, limit }) => {
        const request: any = {};
        if (pattern !== undefined) request.pattern = pattern;
        if (cursor !== undefined) request.cursor = cursor;
        if (limit !== undefined) request.limit = limit;

        return await this.mcp.client.lists.list(request);
      }
    );

    // Get a list by ID
    this.registerToolIfNeeded(
      ListsTools.tools[1],
      "Returns a list based on the list ID provided.",
      {
        list_id: z.string(),
        timeout_in_seconds: z.number().optional(),
        max_retries: z.number().optional(),
      },
      async ({ list_id }) => {
        return await this.mcp.client.lists.get(list_id);
      }
    );

    // Get list subscribers
    this.registerToolIfNeeded(
      ListsTools.tools[2],
      "Get the list's subscriptions.",
      {
        list_id: z.string(),
        cursor: z.string().optional(),
        limit: z.number().optional(),
      },
      async ({ list_id, cursor, limit }) => {
        const request: any = {};
        if (cursor !== undefined) request.cursor = cursor;
        if (limit !== undefined) request.limit = limit;

        return await this.mcp.client.lists.getSubscribers(list_id, request);
      }
    );

    // Create a new list or update an existing one
    this.registerToolIfNeeded(
      ListsTools.tools[3],
      "Upsert a list by list ID.",
      {
        list_id: z.string(),
        name: z.string(),
      },
      async ({ list_id, name }) => {
        const request: any = { name };
        return await this.mcp.client.lists.update(list_id, request);
      }
    );

    // Subscribe a user to a list
    this.registerToolIfNeeded(
      ListsTools.tools[4],
      "Subscribe a user to an existing list (note: if the List does not exist, it will be automatically created).",
      {
        list_id: z.string(),
        user_id: z.string(),
        preferences: z.object({
          categories: z.record(z.any()).optional(),
          notifications: z.record(z.any()).optional(),
        }).optional(),
      },
      async ({ list_id, user_id, preferences }) => {
        // Ensure preferences always has categories and notifications as objects (default to empty if missing)
        const request: any = {
          preferences: {
            categories: preferences?.categories ?? {},
            notifications: preferences?.notifications ?? {},
          }
        };
        return await this.mcp.client.lists.subscribe(list_id, user_id, request);
      }
    );

    // Unsubscribe a user from a list
    this.registerToolIfNeeded(
      ListsTools.tools[5],
      "Delete a subscription to a list by list ID and user ID.",
      {
        list_id: z.string(),
        user_id: z.string(),
      },
      async ({ list_id, user_id }) => {
        return await this.mcp.client.lists.unsubscribe(list_id, user_id);
      }
    );
  }
}
