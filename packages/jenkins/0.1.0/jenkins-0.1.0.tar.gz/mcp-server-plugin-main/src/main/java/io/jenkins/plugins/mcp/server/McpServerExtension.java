/*
 *
 * The MIT License
 *
 * Copyright (c) 2025, Gong Yi.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 */

package io.jenkins.plugins.mcp.server;

import hudson.ExtensionList;
import hudson.ExtensionPoint;
import io.modelcontextprotocol.server.McpServerFeatures;
import java.util.Collections;
import java.util.List;
import jenkins.model.Jenkins;

public interface McpServerExtension extends ExtensionPoint {

    default List<McpServerFeatures.SyncToolSpecification> getSyncTools() {
        return Collections.emptyList();
    }

    default List<McpServerFeatures.SyncPromptSpecification> getSyncPrompts() {
        return Collections.emptyList();
    }

    default List<McpServerFeatures.SyncResourceSpecification> getSyncResources() {
        return Collections.emptyList();
    }

    static ExtensionList<McpServerExtension> all() {
        return Jenkins.get().getExtensionList(McpServerExtension.class);
    }
}
